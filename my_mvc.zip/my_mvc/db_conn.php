<?php
$hostname = "localhost";
$uname = "root";
$pass = "";
$db_name = "blogapp";

try {
    $conn = new PDO("mysql:host=$hostname;dbname=$db_name", 
                    $uname, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
  echo "Connection failed : ". $e->getMessage();
}
?>