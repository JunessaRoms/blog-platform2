<?php
    include "../db_conn.php";
    include "functions.php";
    if (isset($_POST['submit'])){

        $title=$_POST['title'];
        $content=$_POST['content'];
        $category=$_POST['categoryid'];
        $authorId=$_POST['authorid'];

        if(empty($title)||empty($content)||empty($category)||empty($authorId)){
            header("Location: ../index.php?createpost&error=Please fill all inputs");
            exit;
        }else{
            addPost($conn, $title, $content, $category, $authorId);
            header("Location: ../index.php");
            exit;
        }        
   }
?>
