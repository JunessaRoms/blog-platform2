<?php

class PostController {
    public function displayPosts($conn) {
        $allposts =getallpost($conn);
  
        include('view/header.php');
        include('view/post-listing.php');
        include('view/footer.php');
    }

    public function postDetails($conn,$id) {
        $post=getpostbyid($conn,$id);
       
        include('view/header.php');
        include('view/postdetail.php');
        include('view/footer.php');
    }

    public function createPost($conn) {
        include('view/header.php');
        include('view/createpost.php');
        include('view/footer.php');
    }
}

?>