<?php
if (isset($_GET['listpost'])) {
    $postController = new PostController();
    $postController->displayPosts($conn);
} elseif (isset($_GET['postdetails'])) {
    $postController = new PostController();
    $postController->postDetails($conn,$_GET['postdetails']);
}elseif (isset($_GET['createpost'])) {
    $postController = new PostController();
    $postController->createPost($conn);
}
?>