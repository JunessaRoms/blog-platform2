<?php

    function getallpost($conn){
	    $sql="SELECT * FROM posts";
	    $stmt = $conn->prepare($sql);
   	     $stmt->execute();
	    $data =$stmt->fetchAll();
	return $data;	
};
    function getPostbyId($conn,$id){
	    $sql="SELECT * FROM posts INNER JOIN categories ON posts.category_id = categories.category_id 
		INNER JOIN get_authors ON posts.authorid = get_authors.authorid INNER JOIN users ON
		users.userid = get_authors.userid WHERE postid=?";
	    $stmt = $conn->prepare($sql);
   	    $stmt->execute([$id]);
	    $data =$stmt->fetch();
	    return $data;	
};
	function addPost($conn, $title, $content, $category, $author_id){
		$sql = $conn->prepare("INSERT INTO posts (title, content, category_id, authorid)
		VALUES (?, ?, ?, ?)");
		$sql->execute([$title, $content, $category, $author_id]);	
};

	function getallcategory($conn){
		$sql="SELECT * FROM categories";
		$stmt = $conn->prepare($sql);
			$stmt->execute();
		$data =$stmt->fetchAll();
	return $data;	
};

