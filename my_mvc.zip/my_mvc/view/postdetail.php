<?php
        echo "<h4>".$post['postid']."</h4>";
        echo "<h3>".$post['title']."</h3>";
        echo "<h4>".$post['username']."</h4>";
        echo "<p>".$post['category']."</p>";
        echo "<p>".$post['content']."</p>";
?>
