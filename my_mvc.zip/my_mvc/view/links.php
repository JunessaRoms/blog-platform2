<a href="index.php?listpost">Post list</a><br>
<a href="index.php?createpost">Create Post</a>
