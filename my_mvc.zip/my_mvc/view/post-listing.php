<h1>Post List</h1>
<?php	
foreach($allposts as $post){	
	echo "<h4>".$post['postid']."</h4>";
    echo "<h3>".$post['title']."</h3>";
	echo "<p>".$post['content']."</p>";
?>
<a href="index.php?postdetails=<?=$post['postid']?>">View Post Details</a>
<?php }?>
