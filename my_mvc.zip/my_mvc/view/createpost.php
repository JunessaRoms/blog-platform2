<form action="controllers/createfunction.php" method="POST">
    <br>
    <h2>Create Post</h2>
    <label>Title</label>
    <input type="text" name="title"><br>
    <label>Details</label>
    <input type="text" name="content"><br>
    <label>Category</label><br><br>
            <?php 
            $categories=getallcategory($conn);
            foreach($categories as $category){ ?>           
                <input type="radio" name="categoryid" id="cat-<?=$category['category_id']?>" value ="<?=$category['category_id']?>">
                <label for="cat-<?=$category['category_id']?>"><?=$category['category']?></label> <br>          
                <?php }?>
    <br>
    <label>Author Id</label>
    <input type="text" name="authorid"><br>
    <button type="submit" name="submit">Save</button>
</form>
