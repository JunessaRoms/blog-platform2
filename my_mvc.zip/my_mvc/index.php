<?php
    include "db_conn.php";
    include "controllers/functions.php";
    include "controllers/controllerClass.php";
    include "view/header.php";
    include "view/links.php";
    include "view/footer.php";
    include "controllers/postController.php";
?>