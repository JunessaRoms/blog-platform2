
<div class="sidebar">
   

   <ul class="nav_list">
    <?php if($logged){
        $token=$_GET['token']; 
        ?>
        <form action="index.php?" method="GET">
                <input type ="text" placeholder="Search..." name="search">
                <button id="search" type="submit" name="token" value="<?=$token?>">         
                    <i class ="fa-solid fa-search"></i>
                </button>          
        </form><br>
    <?php }else{?>
        <form action="index.php" method="GET">
                <input type ="text" placeholder="Search..." name="search">
                <button id="search" type="submit">         
                    <i class ="fa-solid fa-search"></i>
                </button>          
        </form><br>
    <?php }?>
        
  
        <?php if($logged== true){?>
				<li>
					<a class="side_links" href ="index.php?token=<?=$_GET['token']?>">
						<i class ="fa-solid fa-clipboard"></i>
						<span class="links_name">Home</span>
					</a>
				</li>
                <li>
                    <a class="side_links" href ="user_profile.php?token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-user"></i>
                        <span class="links_name">Profile</span>
                    </a>
                </li>
                <li>
                    <a class="side_links" href ="my_blogs.php?token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-calendar"></i>
                        <span class="links_name">Posts</span>
                    </a>
                </li>
                <li>
                    <a class="side_links" href ="settings.php?token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-gear"></i>
                        <span class="links_name">Settings</span>
                    </a>       
                </li>
                <li>
                    <a class="side_links" href ="help.php?token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-question"></i>
                        <span class="links_name">Help</span>
                    </a>     
                </li>


        <?php }else{?>
		<li>
            <a class="side_links" href ="index.php">
                <i class ="fa-solid fa-clipboard"></i>
                <span class="links_name">Home</span>
            </a>
        </li>

        <li>
            <a class="side_links" href ="login.php">
                <i class ="fa-solid fa-calendar"></i>
                <span class="links_name">Log In First</span>
            </a>
        </li>

            <?php }?>
       
        
   </ul>
  
</div>





