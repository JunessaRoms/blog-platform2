
<?php  if(isset($_GET['pic'])){?>

<form class="details-card" style="width: 800px;" 
action="assets/includes/profile-function.php?userid=<?=$user['userid']?>&token=<?=$_GET['token']?>&pic"
 method="post" enctype="multipart/form-data">
<?php }else{?>
<form class="details-card" style="width: 800px;" 
action="assets/includes/profile-function.php?userid=<?=$user['userid']?>&token=<?=$_GET['token']?>"
 method="post" enctype="multipart/form-data">
 
<?php }?>           
            <?php if($details==0){ ?>
                <div>
                <img src="assets/img/usericon.png" alt="" style="max-width: 180px;">
                </div>
            <?php }else{?>
                <?php if(empty($details['prof_pic'])){?>
                <div>
                <img src="assets/img/usericon.png" alt="" style="max-width: 180px;">
                </div>
                <?php }else{?>
                <div>
                <img src="<?=$details['prof_pic']?>" alt="" style="max-width: 180px;">
                </div>
                <?php }?>
            <?php }?>

            
            
                    <div class="details-text">
                    <div>
                    <h2>USER PROFILE</h2><br><br>
                    <h4>ID: <?=$user['userid']?></h4><br>
                    <h3>Username:</h3>
                    <input type="text" style="width: 400px;" name="username-edit" value="<?=$user['username']?>"><br><br>
                    
                    <?php if($details!=0){ ?>
                        <?php  if(isset($_GET['pic'])){?>
                            <p>Edit Profile Picture: </p>
                            <input type="file" name="image-edit" style="width: 400px;" id="image" accept="image/*">
                            <br>
                        <?php }else{?>
                            <a href="user_profile.php?token=<?=$_GET['token']?>&edit&pic"><p>
                            Edit Profile Picture</p></a><br><br>
                        <?php }?>
                    <p>Firstname: </p>
                    <input type="text" style="width: 400px;"  name="firstname-edit" value="<?=$details['firstname']?>">
                    <p>Lastname: </p>
                    <input type="text" style="width: 400px;"  name="lastname-edit"value="<?=$details['lastname']?>">
                    <br>
                    <?php }else{?>
                        <?php  if(isset($_GET['pic'])){?>
                            <p>Edit Profile Picture: </p>
                            <input type="file" name="image-edit" style="width: 400px;" id="image" accept="image/*">
                            <br>
                        <?php }else{?>
                            <a href="user_profile.php?token=<?=$_GET['token']?>&edit&pic"><p>
                            Edit Profile Picture</p></a><br><br>
                        <?php }?>
                    <p>Firstname: </p>
                    <input type="text" style="width: 400px;"  name="firstname-edit" value="">
                    <p>Lastname: </p>
                    <input type="text" style="width: 400px;"  name="lastname-edit"value="">
                    <br>
                    <?php }?>
                    <p>Email:</p>
                    <input type="text" style="width: 400px;"  name="email-edit" value="<?=$user['email']?>">
                    </div>
                        <button type="submit" name="submit" class="action-btns">
                            <i class ="fa-solid fa-gear"> save</i>
</button>
                    </div>
</form>
