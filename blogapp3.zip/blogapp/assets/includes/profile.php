<div class="main_content">
    <div class="cont_container">
    <?php 

        if(isset($_GET['search'])){
            $key = $_GET['search'];
            $posts = search($db, $key);
            if ($posts == 0) {
                $notFound = 1;
            }
        }
        $user=getuserByUsername($_SESSION['username']);
        $details= getuserDetails($user['userid']);
    ?>

        
        <div class="details-cont">
        <?php if(isset($_GET['edit'])){ 
        include "assets/includes/profile-edit.php";
        }else{ ?>

        <?php if($details==0){?>
            <div class="details-card" style="width: 800px;">
                <div>
                <a href="user_profile.php?edit&pic">
                <img src="assets/img/usericon.png" alt="" style="max-width: 180px;">
                </a>
                </div>
                    <div class="details-text">
                    <div>
                    <h2>USER PROFILE</h2><br><br>
                    <h3>Username: <?=$user['username']?></h3><br>
                    <p><h4>ID: <?=$user['userid']?></h4></p><br>

                    <p>Firstname: Undefined <a href="user_profile.php?edit&token=<?=$_GET['token']?>">
                    <i class ="fa-solid fa-pencil"></i></a></p>
                    <p>Lastname: Undefined <a href="user_profile.php?edit&token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-pencil"></i></a></i></p>
                    <br>
                    <p>Email: <?=$user['email']?></p>
                    </div>
                        <div class="action-btns">
                            <a href="user_profile.php?edit&token=<?=$_GET['token']?>">
                            <i class ="fa-solid fa-gear"> Edit Profile</i></a>
                        </div>
                    </div>
            </div>
        <?php }else{?>
            <div class="details-card" style="width: 800px;">
                <div>
                <?php if(empty($details['prof_pic'])){?>
                <a href="user_profile.php?token=<?=$_GET['token']?>&edit&pic">
                <img src="assets/img/usericon.png" alt="" style="max-width: 180px;">
                </a>
                <?php }else{?>
                    <a href="user_profile.php?token=<?=$_GET['token']?>&edit&pic">
                <img src="<?=$details['prof_pic']?>" alt="" style="max-width: 180px;">
                </a>
                <?php }?>
                
                </div>
                    <div class="details-text">
                    <div>
                    <h2>USER PROFILE</h2><br><br>
                    <h3>Username: <?=$user['username']?></h3><br>
                    <p><h4>ID: <?=$user['userid']?></h4></p><br>
                    <?php if(empty($details['firstname'])){?>
                        <p>Firstname: Undefined <a href="user_profile.php?edit&token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-pencil"></i></a></p>
                    <?php }else{?>
                        <p>Firstname: <?=$details['firstname']?> <a href="user_profile.php?edit&token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-pencil"></i></a></p>
                    <?php }?>
                    <?php if(empty($details['lastname'])){?>
                        <p>Lastname: Undefined <a href="user_profile.php?edit&token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-pencil"></i></a></p>
                    <?php }else{?>
                        <p>Lastname: <?=$details['lastname']?> <a href="user_profile.php?edit&token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-pencil"></i></a></p>
                    <?php }?>        
                    <br>
                    <p>Email: <?=$user['email']?></p>
                    </div>
                        <div class="action-btns">
                            <a href="user_profile.php?edit&token=<?=$_GET['token']?>"><i class ="fa-solid fa-gear"> Edit Profile</i></a>
                            <a href="user_profile.php?dash&token=<?=$_GET['token']?>" 
                            style="margin-left: 10px;"> <i class ="fa-solid fa-chart-line">Dashboard</i></a>
                        </div>
                    </div>
            </div>
        <?php } }?>

        </div>		         
            
    </div>
</div>
