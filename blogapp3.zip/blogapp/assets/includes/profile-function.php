<?php
    include "db.php";
    include "blog.php";

    $userid = $_GET['userid'];
    $details = getuserDetails($userid);
    $token=$_GET['token'];

    

    if ($_SERVER['REQUEST_METHOD'] === 'POST'){

        $username= $_POST['username-edit'];
        $firstname= $_POST['firstname-edit'];
        $lastname= $_POST['lastname-edit'];
        $email= $_POST['email-edit'];
        $userid = $_GET['userid'];

    if(isset($_GET['pic'])){

       
			$image =$_FILES["image-edit"]["name"];

				$targetDirectory = "../img/";
				$imgUrl = "assets/img/" . $image;
				$targetFile = $targetDirectory . $image;
				$uploadOk = 1;
				$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
				

				// Check if the file is an actual image or a fake image
				if (isset($_POST["submit"])) {
					$check = getimagesize($_FILES["image-edit"]["tmp_name"]);
					if ($check === false) {
						$error = "File is not an image.";
						$uploadOk = 0;
						header("Location: ../../user_profile.php?token=$token&error=$error");;
						exit();
					}
				}

			// Allow certain file formats
			$allowedExtensions = ["jpg", "jpeg", "png", "gif"];
			if (!in_array($imageFileType, $allowedExtensions)) {
				$error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
				$uploadOk = 0;
				header("Location: ../../user_profile.php?token=$token&error=$error");
				exit();
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				$error = "Sorry, your file was not uploaded.";
			}

			if (move_uploaded_file($_FILES["image-edit"]["tmp_name"], $targetFile)) {

					if($details==0){
						$sql = "INSERT INTO user_details(userid, firstname, lastname, prof_pic) VALUES (?,?,?,?)";
							$stmt = $db->prepare($sql);
							$stmt->execute([$userid, $firstname, $lastname,$imgUrl]);

						$sql2="UPDATE users SET username=?, email=?
							WHERE userid=?";
						$stmt2 = $db->prepare($sql2);
						$stmt2->execute([$username, $email, $userid]);

						header("Location: ../../user_profile.php?token=$token&error=$error");
						exit;
					}else{

						$sql = "UPDATE user_details SET firstname=?, lastname=?, prof_pic=?
						WHERE userid=?";
							$stmt = $db->prepare($sql);
							$stmt->execute([$firstname, $lastname,$imgUrl, $userid]);

						$sql2="UPDATE users SET username=?, email=?
							WHERE userid=?";
						$stmt2 = $db->prepare($sql2);
						$stmt2->execute([$username, $email, $userid]);

						header("Location: ../../user_profile.php?token=$token");
						exit;

						} 
						}

            }else{
                
            if($details==0){
                $sql = "INSERT INTO user_details(userid, firstname, lastname) VALUES (?,?,?)";
                    $stmt = $db->prepare($sql);
                    $stmt->execute([$userid, $firstname, $lastname]);

                $sql2="UPDATE users SET username=?, email=?
                    WHERE userid=?";
                $stmt2 = $db->prepare($sql2);
                $stmt2->execute([$username, $email, $userid]);

                header("Location: ../../user_profile.php?token=$token&");
                exit;
            }else{

                $sql = "UPDATE user_details SET firstname=?, lastname=? 
                WHERE userid=?";
                    $stmt = $db->prepare($sql);
                    $stmt->execute([$firstname, $lastname, $userid]);

                $sql2="UPDATE users SET username=?, email=?
                    WHERE userid=?";
                $stmt2 = $db->prepare($sql2);
                $stmt2->execute([$username, $email, $userid]);

                header("Location: ../../user_profile.php?token=$token");
                exit;

                } 

            
            } 
    }
?>