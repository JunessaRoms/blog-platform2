        <div class="action-btns">
                    <?php if($logged){
                        $user=getuserByUsername($_SESSION['username']);
                        $liked = isLikedByUserID($post['postid'], $user['userid'])
                    ?>
                        <?php if($liked){ ?>
                            <i class ="fa-solid fa-thumbs-up liked" id="like-btn-<?=$post['postid']?>"
                            value="<?=$post['postid']?>"
                            onclick ="likeFunc('like-btn-<?=$post['postid']?>','like-num-<?=$post['postid']?>',
                            '<?=$user['userid']?>')">
                        <?php }else{?>
                            <i class ="fa-solid fa-thumbs-up unliked" id="like-btn-<?=$post['postid']?>"
                            value="<?=$post['postid']?>"
                            onclick ="likeFunc('like-btn-<?=$post['postid']?>','like-num-<?=$post['postid']?>',
                            '<?=$user['userid']?>')">
                        <?php }?>
                            Likes</i>
                            (<span id="like-num-<?=$post['postid']?>"><?php echo countLikePostId($db, $post['postid'])?></span>)
                       
                    <?php }else{?>
                    <i class ="fa-solid fa-thumbs-up"> Likes</i>
                        (<span><?php echo countLikePostId($db, $post['postid'])?></span>)
                    <?php } if($logged){?>
                    <a href="read_more.php?postid=<?=$post['postid']?>&token=<?=$_GET['token']?>"
                    style="color:black">
                    <i class ="fa-solid fa-message"> Comments</i></a>
                    <?php }else{?>
                    <a href="read_more.php?postid=<?=$post['postid']?>"
                    style="color:black">
                    <i class ="fa-solid fa-message"> Comments</i></a>
                    <?php }?>
                        (<span><?php echo countCommentPostId($db, $post['postid'])?></span>)
        </div>