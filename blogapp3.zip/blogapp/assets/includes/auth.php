<?php
session_start();
require_once 'db.php';

function authenticateUser($username, $password) {
    global $conn;

    // Implement code to check user credentials against the database
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            return true;
        }
    }

    return false;
}

function isUserAuthenticated() {
    return isset($_SESSION['user_id']);
}

function authorizeUser($requiredRole) {
    if (!isUserAuthenticated()) {
        // User is not authenticated, redirect to login page or deny access
        redirectToLogin();
    }

    // Check if the user has the required role
    $allowedRoles = array("admin", "editor", "author"); // Define your roles here
    $userRole = getUserRole(); // You need to implement a function to get the user's role

    if (!in_array($userRole, $allowedRoles) || $userRole !== $requiredRole) {
        // User does not have the required role, redirect to unauthorized page or deny access
        redirectToUnauthorized();
    }
}

// Function to get the user's role from the database or session
function getUserRole() {
    // Implement code to get the user's role from the database or session
    // Return the user's role (e.g., "admin", "editor", "author")
}

function redirectToLogin() {
    // You might want to store the intended destination before redirecting
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    
    // Redirect to the login page
    header("Location: login.php");
    exit();
}

function redirectToUnauthorized() {
    // Redirect to the unauthorized page or deny access
    header("Location: unauthorized.php");
    exit();
}
?>
