<?php
    include "../includes/db.php";
    include "../includes/blog.php";

    $postid = $_GET['postid'];
    $commentid = $_GET['commentid'];
    $token = $_GET['token'];
    
    deleteCommentById($commentid);

            header("Location: ../../read_more.php?postid=$postid&token=$token");
            exit;

      
    

?>