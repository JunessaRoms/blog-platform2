<?php
 if(isset($_GET['search'])){
    $key = $_GET['search'];
    $posts = search($db, $key);
    if ($posts == 0) {
        $notFound = 1;
    }
 }else {
    $posts = getAll($db);
 }

?>