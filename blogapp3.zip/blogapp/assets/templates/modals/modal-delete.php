<div id="myModal-<?=$post['postid']?>" class="modal">
                        <!-- Modal content -->
    <div class="modal-content">
    <span class="close" onclick ="CloseModal('myModal-<?=$post['postid']?>')">&times;</span>
        <p>DELETE POST?</p><br><br>
        <a href="assets/templates/delete_post.php?post_id=<?= $post['postid']?>" 
            ><button><h3>Yes</h3></button></a>
    <button onclick ="CloseModal('myModal-<?=$post['postid']?>')"><h3>No</h3></button>
    </div>
</div>