<div class="main_content">
    <div class="cont_container">
    <?php 
    $pID= $_GET['postid'];

        if(isset($_GET['search'])){
            $key = $_GET['search'];
            $posts = search($db, $key);
            if ($posts == 0) {
                $notFound = 1;
            }
        }else {
            $post = getPostById($pID);
            $category= getCategoryById($post['category_id']);
        }
    ?>

        
        <div class="details-cont">


            <div class="details-card">
                <div>
                <img src="<?=$post['image']?>" alt="" style="max-width: 350px;">
                </div>
                    <div class="details-text">
                    <div>
                    <h2><?=$post['title']?></h2><br>
                    <p><h4>Genre: <?=$category['category']?></h4></p><br>
                    <p><?=$post['content'] ?></p>
                    </div>
                        <div class="action-btns">
                            <i class ="fa-solid fa-thumbs-up"> Likes</i>
                                (<span><?php echo countLikePostId($db, $post['postid'])?></span>)
                            <i class ="fa-solid fa-message"> Comments</i>
                                (<span><?php echo countCommentPostId($db, $post['postid'])?></span>)
                        </div>
                    </div>
            </div>
        </div>
			         
              <?php include "assets/templates/comment-section.php" ?>       
            
    </div>
</div>
