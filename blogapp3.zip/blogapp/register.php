<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/registerstyle.css">
    <title>Registration</title>
</head>
<body>
    <div class="container">
        <div class="signform">
        <h2>Create Account</h2>
        <form action="register_function.php" method="post">
            <?php if (isset($_GET['error'])) { ?>
                <p class="error"><?php echo $_GET['error']; ?></p>
            <?php } ?>
            <?php if (isset($_GET['success'])) { ?>
                <p class="success"><?php echo $_GET['success']; ?></p>
            <?php } ?>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username"><br><br>

            <label for="email">Email:</label>
            <input type="text" id="email" name="email"><br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password"><br><br>
            <label for="confirmpassword">Confirm Password:</label>
            <input type="password" id="confirmpassword" name="confirmpassword"><br><br>


            <div class="button-container">
            <input type="submit" value="CREATE"></input>
            <a id="signin" href="login.php">SIGN IN</a>
            </div>
    </form>
        </div>
    </div>
    
</body>
</html>