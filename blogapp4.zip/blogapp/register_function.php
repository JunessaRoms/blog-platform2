<?php
session_start();
include ('assets/includes/db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmpass = $_POST['confirmpassword'];


    if(empty($username)){
            header("Location: register.php?error=Enter username");
            exit;
        
    }else if(empty($email)){
            header("Location: register.php?error=Enter email");
            exit;
    }else if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            
            if(empty($password)){
                header("Location: register.php?error=Enter Password");
                exit;
                
            }elseif(strlen($password)<12){
                header("Location: register.php?error=Password length be at least 12");
                exit;
                
            }else if(empty($confirmpass)){
                    header("Location: register.php?error=Confirm Password");
                    exit;
                    
            }else if($password === $confirmpass) {
                    //Check if user exists
                    $sql = "SELECT * FROM users WHERE username='$username' OR email ='$email' ";
                    $result = $db->query($sql);

                        if ($result->rowCount() === 0 ) {
                            //Successfully registered
                            registerUser($username, $email, $password,$db);
                            header("Location: register.php?success=Account Successfully created!");
                            exit;
                        } else {
                            // Registration failed
                            header("Location: register.php?error=User Exists");
                            exit;
                        }
            } else {
                header("Location: register.php?error=Password Mismatch");
                exit;
            }
                
            } else {
                // Invalid email format
                header("Location: register.php?error=Invalid Email");
                exit;
            }
    
}
// Define the registration function to handle user registration
function registerUser($username, $email, $password,$db){

    // Hash the password for security
    $password = password_hash($password, PASSWORD_BCRYPT);
   

     // Insert user data into the database
    $insertQuery = "INSERT INTO users (username, email, password) VALUES (?,?,?)";
    $insertStmt = $db->prepare($insertQuery);
    $insertStmt->execute([$username, $email, $password]);
}
?>