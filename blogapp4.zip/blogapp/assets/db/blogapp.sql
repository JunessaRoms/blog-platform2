-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2023 at 10:46 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category`) VALUES
(1, 'Sci-Fi'),
(2, 'Romance'),
(3, 'Mystery');

-- --------------------------------------------------------

--
-- Table structure for table `get_authors`
--

CREATE TABLE `get_authors` (
  `authorid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `get_authors`
--

INSERT INTO `get_authors` (`authorid`, `userid`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageid` int(11) NOT NULL,
  `message` text NOT NULL,
  `userid` int(11) NOT NULL,
  `chatdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageid`, `message`, `userid`, `chatdate`) VALUES
(3, 'fff', 2, '2023-12-30 14:23:19'),
(5, 'bro', 2, '2023-12-30 14:26:49'),
(6, 'Skibidii!!!', 1, '2023-12-30 14:37:22'),
(7, 'Sigma!!!', 1, '2023-12-30 17:23:23'),
(8, 'GIGACHAD!!', 3, '2023-12-30 17:38:09');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `postid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `authorid` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`postid`, `title`, `category_id`, `content`, `authorid`, `image`, `create_at`) VALUES
(1, 'Cyber-stuff', 1, 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Recusandae est explicabo modi ullam consectetur odit dignissimos in minus quidem! Esse voluptates, nam vitae nemo mollitia in soluta aspernatur quod earum?', 1, 'assets/img/Picsart_23-12-08_10-46-34-603.jpg', '2023-12-05 12:39:21'),
(7, 'The Fae', 2, 'i7fuyf yxtd txre s5s4 6 5d7tf7tfu87 ', 1, 'assets/img/Cherry_Blossom_Fairy.png', '2023-12-24 06:48:58'),
(8, 'BIZZZ', 3, 'BBBBB', 3, 'assets/img/Picsart_23-12-08_02-50-20-151.jpg', '2023-12-24 12:35:46'),
(9, 'The Hunter', 2, '98747890987654456789', 2, 'assets/img/The Hunter - Unlikely Alliance by ElinTan on DeviantArt.png', '2023-12-24 13:07:43');

-- --------------------------------------------------------

--
-- Table structure for table `post_comment`
--

CREATE TABLE `post_comment` (
  `commentid` int(11) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `commentdate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_comment`
--

INSERT INTO `post_comment` (`commentid`, `comment`, `postid`, `userid`, `commentdate`) VALUES
(1, 'Wow, I don\'t get it.', 1, 1, '2023-12-05'),
(15, 'Bruh!!..', 1, 2, '2023-12-25'),
(16, 'Yo..', 7, 2, '2023-12-25'),
(18, 'Holy Shit!!', 7, 2, '2023-12-25'),
(19, 'yeah', 1, 1, '2023-12-25'),
(20, 'yo', 8, 1, '2023-12-27'),
(22, 'sss', 7, 1, '2023-12-29');

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `likeid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `likedate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`likeid`, `postid`, `userid`, `likedate`) VALUES
(11, 1, 1, '2023-12-24'),
(14, 7, 2, '2023-12-24'),
(15, 1, 2, '2023-12-24'),
(16, 8, 3, '2023-12-24'),
(17, 1, 3, '2023-12-24'),
(18, 9, 2, '2023-12-24'),
(19, 9, 3, '2023-12-24'),
(20, 7, 3, '2023-12-24'),
(21, 7, 1, '2023-12-25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(150) NOT NULL,
  `user_token` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `email`, `password`, `user_token`) VALUES
(1, 'dice', 'dice123@gmail.com', '$2y$10$sYkqfNkX1rlQw5BuKaiIuuphu01Gu3fIoT6duSLQt5OVbNhEw3wnK', '80eda9'),
(2, 'dud2', 'bruh@email.com', '$2y$10$DSJqtiBNCrQZGQTVXpyAuu9ZhMhWXGpokXF.CvARZGHzD6l4RhrNi', '03ab6e'),
(3, 'jay123', 'jay@gmail.com', '$2y$10$PgZ9j9Pr2h5CwzIemOH8fOlE5PS0ilv1VEPrDz7lpGoANbG1y98ae', '3f7da4');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `userid` int(11) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `prof_pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`userid`, `firstname`, `lastname`, `prof_pic`) VALUES
(1, 'Junessa', 'Romanillos', 'assets/img/Flower Creature Art.png'),
(2, 'Dude', 'Mann', 'assets/img/1.png'),
(3, 'jay', '123', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `get_authors`
--
ALTER TABLE `get_authors`
  ADD PRIMARY KEY (`authorid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageid`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`postid`);

--
-- Indexes for table `post_comment`
--
ALTER TABLE `post_comment`
  ADD PRIMARY KEY (`commentid`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`likeid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `get_authors`
--
ALTER TABLE `get_authors`
  MODIFY `authorid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `post_comment`
--
ALTER TABLE `post_comment`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `likeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
