<?php
    include "../includes/db.php";
    include "../includes/blog.php";

    $postid = $_GET['postid'];
    $userid = $_GET['userid'];
    if(isset($_POST['comment'])){
        $comment = $_POST['comment'];

        if(!empty($comment)){
                    
            $sql = "INSERT INTO post_comment(comment, postid, userid) VALUES (?,?,?)";
            $stmt = $db->prepare($sql);
            $stmt->execute([$comment,$postid,$userid]);

            header("Location: ../../read_more.php?postid=$postid");
            exit;
        }else{
            header("Location: ../../read_more.php?postid=$postid&error=Comment is Empty");
            exit;
        }
    
    }
?>