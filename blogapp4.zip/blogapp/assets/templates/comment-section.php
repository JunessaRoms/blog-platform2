<div class="comment-cont">
                <?php 
                    $user=getUserbyUname($_SESSION['username']);

                    $commentsPerPage = 5;
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;       

                    $startIndex = ($page - 1) * $commentsPerPage;
                    $comments = getCommentsByPost($post['postid'], $startIndex, $commentsPerPage);

                    if($comments != 0){
                        foreach($comments as $comment){         
                        $usercomm=getUserbyID($comment['userid']);
                ?>

                <?php if($comment['userid']==$user['userid']){ ?>
                    <?php if(isset($_GET['edit'])){?>
                    <?php $commID=$_GET['edit'];
                        $comm= getCommentById($commID);
                        if($comment['commentid']==$commID){
                    ?>               
                    
                        <form class="comment-card" style="background: #d291fd;" method="post" 
                        action="assets/templates/commentedit.php?postid=<?=$pID?>&page=<?=$page?>
                        &comm_id=<?=$comm['commentid']?>&token=<?=$_GET['token']?>">
                        <h3><?=$usercomm['username']?></h3>
                        <p><?=$comm['commentdate']?></p>
                        <textarea type="text" name="commentedit" id="commentedit"></textarea><br>

                        <button type="submit">Save</button>
                        </form><br>

                        <script>
                            document.getElementById("commentedit").value ="<?=$comm['comment']?>";
                        </script>

                    <?php } }else{
                        $text=badwordfilter($comment['comment']);?>
                    <div class="comment-card" style="background: #d291fd;">
                    <h3><?=$usercomm['username']?></h3>
                    <p><?=$comment['commentdate']?></p>
                    <br>    
                    <p><?=$text?></p>
                    <br>
                    
                    <a href="read_more.php?postid=<?=$pID?>&page=<?=$page?>&edit=<?=$comment['commentid']?>
                    &token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-pencil"></i></a>
                    
                    <a  href="assets/templates/commentdelete.php?postid=<?=$pID?>&commentid=<?=$comment['commentid']?>
                    &token=<?=$_GET['token']?>">
                        <i class ="fa-solid fa-trash"></i></a>

                </div><br>
                    <?php }?>
                <?php }else{
                    $text=badwordfilter($comment['comment']);?>
                <div class="comment-card">
                    <h3><?=$usercomm['username']?></h3>
                    <p><?=$comment['commentdate']?></p>
                    <br>    
                    <p><?=$text?></p>
                </div><br>
                <?php }?>
                <?php }}else{ ?>
                    <div class="comment-card">    
                    <p>No comments yet</p>
					</div> <br> 
                    <?php } ?>

                        <?php
                            if($logged){
                            }
                                $sqlCount = "SELECT COUNT(*) AS total FROM post_comment WHERE postid=$pID";
                                $resultCount = $db->query($sqlCount);
                                $rowCount = $resultCount->fetch();
                                $totalComments = $rowCount['total'];
                                $totalPages = ceil($totalComments / $commentsPerPage);
                                $token=$_GET['token'];
                                
                            for ($i = 1; $i <= $totalPages; $i++) {
                                echo "<a href='read_more.php?postid=$pID&page=$i&token=$token'> $i</a>";
                            }
                        ?>
                        <br>
            </div>
            <br>
			<div class="comment-input-box">		
                <?php if($logged){ ?>
   
                        <form class="comment-input" action="assets/templates/commentfunc.php?postid=<?=$post['postid']?>&userid=<?=$user['userid']?>
                        &token=<?=$_GET['token']?>"
                        method="post">
                        <h4 >Write your comment:</h4>
                        <?php if (isset($_GET['error'])) { ?>
                            <p style="color:darkred;"><?php echo $_GET['error']; ?></p>
                        <?php } ?>

                        <textarea type="text" name="comment" class="commentbox"></textarea><br>

                        <button type="submit">Send</button>
                        </form>

                    <?php }else{?>
                        <div class="comment-input">
                        <h4>Login First</h4>
                        </div>
                    <?php }?>
            </div>