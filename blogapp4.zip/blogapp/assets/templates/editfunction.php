<?php
// Include the necessary files (db.php, authentication, etc.)

require_once '../includes/db.php';

// Start the session if not already started
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if the user is not logged in
    header('Location: .../../../../login.php');
    exit();
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the form
    $postid=$_GET['postid'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = $_GET['authorID']; 
    $category_id = $_POST['category'];
    $image =$_FILES["image"]["name"];

    // Validate form data (add more validation as needed)
    if (empty($title) || empty($content)) {
        $error = "Title and content are required";
    } else {
        // Handle file upload
        $targetDirectory = "../img/";
        $imgUrl = "assets/img/" . $image;
        $targetFile = $targetDirectory . $image;
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if the file is an actual image or a fake image
        if (isset($_POST["submit"])) {
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if ($check === false) {
                $error = "File is not an image.";
                $uploadOk = 0;
                header("Location: ../../new_post.php?error=$error&authorID=$author");
                exit();
            }
        }

        // Check if the file already exists
        /*
        if (file_exists($targetFile)) {
            $error = "Sorry, this file already exists.";
            $uploadOk = 0;
            header("Location: ../../new_post.php?error=$error");
            exit();
        }*/

        // Check file size
        /*if ($_FILES["image"]["size"] > 500000) {
            $error = "Sorry, your file is too large.";
            $uploadOk = 0;
            header("Location: ../../new_post.php?error=$error");
            exit();
        }*/

        // Allow certain file formats
        $allowedExtensions = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType, $allowedExtensions)) {
            $error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
            $uploadOk = 0;
            header("Location: ../../new_post.php?error=$error&authorID=$author");
            exit();
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            $error = "Sorry, your file was not uploaded.";
        } else {
            // If everything is ok, try to upload the file
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                // Insert the new post into the database with the image filename
                $query = $db->prepare("UPDATE posts SET title=?, category_id=?, content=?, authorid=? ,image=?
                WHERE postid=$postid");
                $query->execute([$title, $category_id ,$content, $author, $imgUrl]);
                
                // Redirect to the dashboard or post list page after successful submission
                $success = "Successfully Updated";
                header("Location: ../../new_post.php?success=$success&authorID=$author");
                exit();
            } else {
                $error = "Sorry, there was an error uploading your file.";
                header("Location: ../../new_post.php?error=$error&authorID=$author");
            exit();
            }
        }
    }
}