<div class="main_content">
    <div class="cont_container">
    <?php 

        if(isset($_GET['search'])){
            $key = $_GET['search'];
            $posts = search($db, $key);
            if ($posts == 0) {
                $notFound = 1;
            }
        }
        $user=getuserByUsername($_SESSION['username']);
        $details= getuserDetails($user['userid']);
        $author= getAuthor($user['userid']);

        $posts=getPostByAuthorId($author['authorid']);
        $postTotalCount = getPostCountAuthorId($author['authorid']);
        $commentsCount =getCommentCountByUserId($user['userid']);
        $comments=getCommentByUserId($user['userid']);

    ?>

        
<div class="details-cont">
        
            <div class="dashboard-card" style="width: 750px; height: 400px;">
               
                    <div class="dash-cont">
                        <div>
                        <h2>POSTS</h2><br>
                        <p>Total No. of Post: <?=$postTotalCount?></p><br>

                        <div class="dash-post">
                        <table>
                            <tr>
                                <th>Post ID</th>
                                <th>Cover</th>
                                <th>Title</th>
                                <th>Content</th>
                                <th>Creation Date</th>
                            </tr>
                            <?php foreach($posts AS $post){
                            $post_snip = strip_tags($post['content']); 
                            $post_snip = substr($post_snip, 0, 18);    
                            ?>
                            <tr>
                                <td><?=$post['postid']?></td>
                                <td><img src="<?=$post['image']?>" alt="" style="width: 60px;"></td>
                                <td><?=$post['title']?></td>
                                <td><?=$post_snip?>...</td>
                                <td><?=$post['create_at']?><td>
                            </tr>
                            <?php }?>
                        </table>
                            </div>
                        </div>
                    </div>
            </div>

            <div class="dashboard-card" style="width: 600px; height: 400px;">
               
                    <div class="dash-cont">
                        <div>
                        <h2>COMMENTS</h2><br>
                        <p>Total No. of Comments: <?=$commentsCount?></p><br>

                        <div class="dash-post">
                        <table>
                            <tr>
                                <th>Title</th>
                                <th>Comment</th>
                                <th>Comment Date</th>
                            </tr>
                            <?php foreach($comments AS $comment){
                            $post= getPostById($comment['postid']);
                            $comm_snip = strip_tags($comment['comment']); 
                            $comm_snip = substr($comm_snip, 0, 19);    
                            ?>
                            <tr>
                                <td><a href="read_more.php?postid=<?=$comment['postid']?>&page=1&token=<?=$_GET['token']?>">
                                <?=$post['title']?></a></td>
                                <td><?=$comm_snip?>...</td>
                                <td><?=$comment['commentdate']?><td>
                                
                            </tr>
                            <?php }?>
                        </table>
                            </div>
                        </div>
                    </div>
            </div>

        </div>		         
        </div>     
    </div>
</div>
