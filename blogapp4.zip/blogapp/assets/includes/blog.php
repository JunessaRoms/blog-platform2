<?php
require_once 'db.php';


function search($key){ 
    global $db;
    $key = "%{$key}%";
    $sql = "SELECT * FROM posts 
            WHERE (title LIKE ? 
            OR content LIKE ?)";
    $stmt = $db->prepare($sql);
    $stmt->execute([$key, $key]);
 
    if($stmt->rowCount() >= 1){
          $data = $stmt->fetchAll();
          return $data;
    }else {
        return 0;
    }
 }

 // count likes by post id
 function countLikePostId($conn, $id){
    $sql= "SELECT * FROM post_likes WHERE postid='$id'";
    $stmt= $conn->query($sql);
    if($stmt->rowCount()>0){
        return $stmt->rowCount();
    }else{
        return 0;
    }
   
 }

function countCommentPostId($conn, $id){
    $sql= "SELECT * FROM post_comment WHERE postid='$id'";
    $stmt= $conn->query($sql);
    if($stmt->rowCount()>0){
        return $stmt->rowCount();
    }else{
        return 0;
    }
 }

function getCommentsbyPostID($postid) {
    global $db;
    $sql = $db->prepare("SELECT * FROM post_comment WHERE postid = ?");
    $sql->execute([$postid]);
    
    if($sql->rowcount()>0){
        $result = $sql->fetchAll();
        return $result;
    }else{
        return 0;
    }
}


function getAllPost(){
    global $db;
    $sql = "SELECT * FROM posts ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
 
    if($stmt->rowCount() >= 1){
           $data = $stmt->fetchAll();
           return $data;
    }else {
         return 0;
    }
 }

 function getPostById($id){
   global $db;
   $sql = "SELECT * FROM posts WHERE postid=? ";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
          $data = $stmt->fetch();
          return $data;
   }else {
        return 0;
   }
}

function getPostByAuthorId($id){
   global $db;
   $sql = "SELECT * FROM posts WHERE authorid=? ";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
          $data = $stmt->fetchAll();
          return $data;
   }else {
        return 0;
   }
}


function getPostCountAuthorId($id){
   global $db;
   $sql = "SELECT * FROM posts WHERE authorid=? ";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
          $data = $stmt->rowCount();
          return $data;
   }else {
        return 0;
   }
}
 
 function getUserbyUname($username){
    global $db;
    $sql = "SELECT * FROM users WHERE username=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$username]);
 
    if($stmt->rowCount() >= 1){
           $data = $stmt->fetch();
           return $data;
    }else {
         return 0;
    }
 }

 

 function getAuthor($userid){
    global $db;
    $sql = "SELECT * FROM get_authors WHERE userid=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$userid]);
 
    if($stmt->rowCount() >= 1){
           $data = $stmt->fetch();
           return $data;
    }else {
         return 0;
    }
 }

 
 function getAuthorUser($authorid){
    global $db;
    $sql = "SELECT * FROM get_authors WHERE authorid=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$authorid]);
 
    if($stmt->rowCount() >= 1){
           $data = $stmt->fetch();
           return $data;
    }else {
         return 0;
    }
 }

 function getUserbyID($id){
    global $db;
    $sql = "SELECT * FROM users WHERE userid=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$id]);
 
    if($stmt->rowCount() >= 1){
           $data = $stmt->fetch();
           return $data;
    }else {
         return 0;
    }
 }

 function getuserByUsername($username){
   global $db;
   $sql = "SELECT * FROM users WHERE username=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$username]);

   if($stmt->rowCount() == 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getuserDetails($id){
   global $db;
   $sql = "SELECT * FROM user_details WHERE userid=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() == 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

 function get5Categories(){
    global $db;
    $sql = "SELECT * FROM categories LIMIT 5";
    $stmt = $db->prepare($sql);
    $stmt->execute();
 
    if($stmt->rowCount() >= 1){
           $data = $stmt->fetchAll();
           return $data;
    }else {
         return 0;
    }
 }

 function getAllCategories(){
   global $db;
   $sql = "SELECT * FROM categories";
   $stmt = $db->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
          $data = $stmt->fetchAll();
          return $data;
   }else {
        return 0;
   }
}

function getCategoryById($id){
   global $db;
   $sql = "SELECT * FROM categories WHERE category_id=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
          $data = $stmt->fetch();
          return $data;
   }else {
        return 0;
   }
}
 
 function getPostbyCategory($id){
    global $db;
    $sql = "SELECT * FROM posts WHERE category_id=$id";
    $stmt = $db->prepare($sql);
    $stmt->execute();
 
    if($stmt->rowCount() >= 1){
           $data = $stmt->fetchAll();
           return $data;
    }else {
         return 0;
    }
 }

 function isLikedByUserID($postid, $userid){
   global $db;
   $sql = "SELECT * FROM post_likes WHERE postid=? AND userid=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$postid, $userid]);

   if ($stmt->rowCount() > 0) {
      return 1;
   }else return 0;
}

function getCommentsByPost($id, $start, $commentsPerPage){
   global $db;
   $sql = "SELECT * FROM post_comment WHERE postid=? ORDER BY commentid desc
   LIMIT $start, $commentsPerPage";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
      $data = $stmt->fetchAll();
      return $data;
   }else {
       return 0;
   }
}

function getUserCommentByPost($Uid, $Pid){
   global $db;
   $sql = "SELECT * FROM post_comment WHERE postid=? & userid=? ";
   $stmt = $db->prepare($sql);
   $stmt->execute([$Pid, $Uid]);

   if($stmt->rowCount() >= 1){
      $data = $stmt->fetch();
      return $data;
   }else {
       return 0;
   }
}


function getCommentById($id){
   global $db;
   $sql = "SELECT * FROM post_comment WHERE commentid=? ";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
      $data = $stmt->fetch();
      return $data;
   }else {
       return 0;
   }
}

function getCommentByUserId($id){
   global $db;
   $sql = "SELECT * FROM post_comment WHERE userid=? ";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
      $data = $stmt->fetchAll();
      return $data;
   }else {
       return 0;
   }
}

function getCommentCountByUserId($id){
   global $db;
   $sql = "SELECT * FROM post_comment WHERE userid=? ";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
      $data = $stmt->rowCount();
      return $data;
   }else {
       return 0;
   }
}

function deleteCommentById($id){
   global $db;
   $sql = "DELETE FROM post_comment WHERE commentid=?";
   $stmt = $db->prepare($sql);
   $result = $stmt->execute([$id]);

   
}

function badwordfilter($text) {
   $badwordList = array("shit", "fuck", "bitch", "asshole", "motherfucker"); 

   foreach ($badwordList as $word) {
       $replacement = str_repeat("*", strlen($word));
       $text = preg_replace("/\b$word\b/i", $replacement, $text);
   }

   return $text;
}

?>