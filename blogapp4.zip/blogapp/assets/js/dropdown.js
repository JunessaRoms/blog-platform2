let profbtn = document.querySelector("#profbtn");
let catbtn = document.querySelector("#cat-btn");
let catdropcont = document.querySelector(".cat-dropdown_cont");
let dropcont = document.querySelector(".dropdown_cont");

let cat_create = document.querySelector("#cat_drop");
let cat_create_cont = document.querySelector(".cat_drop_cont");

catbtn.onclick = function(){
    catdropcont.classList.toggle("active");
  }

profbtn.onclick = function(){
    dropcont.classList.toggle("active");
  }

cat_create.onclick = function(){
  cat_create_cont.classList.toggle("active");
  }
