function ShowModal(id) {
    var modal = document.getElementById(id);
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
function CloseModal(id) {
    var modal = document.getElementById(id);
    modal.style.display = "none";
}