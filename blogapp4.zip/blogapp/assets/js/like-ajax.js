function likeFunc(LikeID, SpanID, UserID) {
    const clss = document.getElementById(LikeID);
    var value = document.getElementById(LikeID).getAttribute('value');
    var user= UserID;
    var xhr = new XMLHttpRequest();

    if(clss.className=="fa-solid fa-thumbs-up liked"){
        clss.className= "fa-solid fa-thumbs-up unliked";
    }else{
        clss.className= "fa-solid fa-thumbs-up liked";
    }

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) { 
            if (xhr.status === 200) {
                document.getElementById(SpanID).innerHTML = xhr.responseText;
                
            } else {
                document.getElementById(SpanID).innerHTML = 'Error occurred.';
            }
        }
    };

    xhr.open('POST', 'assets/templates/likefunction.php?userid='+user, true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send('postid=' + encodeURIComponent(value));
}