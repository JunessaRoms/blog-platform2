<?php
    include "assets/includes/db.php";
    include "assets/includes/blog.php";

    $userid = $_GET['userid'];

    $sql = "INSERT INTO get_authors(userid) VALUES (?)";
    $stmt = $db->prepare($sql);
    $stmt->execute([$userid]);

    $sql2= "SELECT * FROM get_authors WHERE userid=?";
    $stmt2 = $db->prepare($sql2);
    $stmt2->execute([$userid]);
    
    if($stmt2->rowCount() >= 1){
 
    $author = $stmt2->fetch();
    $au =$author['authorid'];

    header("Location: mypost.php?authorID=$au");
    exit;
    }

?>