<?php
include "assets/includes/db.php";

    $messageid = $_POST['mID'];

    $sql = "DELETE FROM messages WHERE messageid=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$messageid]);


?>