<?php
include "assets/includes/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $message =$_POST['message'];
    $userid = $_GET['userid'];

    $stmt = $db->prepare('INSERT INTO messages(message, userid) VALUES (?,?)');
    $stmt->execute([$message, $userid]);

}

?>