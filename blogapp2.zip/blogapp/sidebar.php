
<div class="sidebar">
   

   <ul class="nav_list">
        <form action="index.php" method="GET">
                <input type ="text" placeholder="Search..." name="search">
                <button id="search" type="submit">         
                    <i class ="fa-solid fa-search"></i>
                </button>          
        </form><br>
        <li>
            <a class="side_links" href ="index.php">
                <i class ="fa-solid fa-clipboard"></i>
                <span class="links_name">Home</span>
            </a>
        </li>
  
        <?php if($logged== true){?>

                <li>
                    <a class="side_links" href ="user.php">
                        <i class ="fa-solid fa-user"></i>
                        <span class="links_name">Profile</span>
                    </a>
                </li>
                <li>
                    <a class="side_links" href ="my_blogs.php">
                        <i class ="fa-solid fa-calendar"></i>
                        <span class="links_name">Posts</span>
                    </a>
                </li>
                <li>
                    <a class="side_links" href ="messages.php">
                        <i class ="fa-solid fa-message"></i>
                        <span class="links_name">Chats</span>
                    </a>
                </li>
                <li>
                    <a class="side_links" href ="settings.php">
                        <i class ="fa-solid fa-gear"></i>
                        <span class="links_name">Settings</span>
                    </a>       
                </li>
                <li>
                    <a class="side_links" href ="help.php">
                        <i class ="fa-solid fa-question"></i>
                        <span class="links_name">Help</span>
                    </a>     
                </li>


        <?php }else{?>

        <li>
            <a class="side_links" href ="login.php">
                <i class ="fa-solid fa-calendar"></i>
                <span class="links_name">Log In First</span>
            </a>
        </li>

            <?php }?>
       
        
   </ul>
  
</div>





