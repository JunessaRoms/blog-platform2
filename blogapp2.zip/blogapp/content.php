<div class="main_content">
    <div class="cont_container">
    <?php 
        if(isset($_GET['search'])){
            $key = $_GET['search'];
            $blogs = search($key);
            if ($blogs == 0) {
                $notFound = 1;
            }
        }else {
            $blogs = getAllPost();
        }
    ?>
<?php if($blogs >0){

    foreach($blogs as $post){ ?>
    <div class="post_card">
        <img src="<?=$post['image']?>" alt="" style="max-width: 350px;">
            <div class="subcon">
            <h3><?=$post['title']?></h3>

            <?php 
            $authoruser= getAuthorUser($post['authorid']);
            $author = getUserbyID($authoruser['userid']);
            ?>
             <p>Author: <?=$author['username']?></p>
             <p>(<?=$post['create_at']?>)</p><br>

            <?php
            $cont =strip_tags($post['content']);
            $cont = substr($cont,0, 250);
            ?>
            <p><?=$cont?>...</p>
            <a href="read_more.php?postid=<?=$post['postid']?>&page=1">Read more</a>
              <?php include "assets/includes/actionbtns.php";?>
            </div>
    </div>
<?php } }?>
    </div>
</div>

