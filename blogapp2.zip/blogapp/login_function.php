<?php
session_start();
include 'assets/includes/db.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Call the login function to validate user credentials

  
    if(empty($username)){
        header("Location: login.php?error=Enter username");
        exit;
    }else if(empty($password)){
        header("Location: login.php?error=Enter password");
        exit;
    }else{

        $row = findUser($username, $db);  
        if ($row->rowCount()===1) {

            $user=$row->fetch();
            $hashpass=$user['password'];

            if(password_verify($password,$hashpass)){

                $_SESSION['username']=$_POST['username'];
            
            // Login was successful
            header("Location: index.php");
            exit;

                if(isset($_POST['remember'])&& $_POST['remember'] ==='on'){
                    $cookie_expire = time() + 7 * 24 * 60 * 60; //7days
                    setcookie('remember_me_cookie', $username, $cookie_expire, '/');
                }
                header("Location: login.php");
                exit;
            }
            else{
                header("Location: login.php?error=Wrong Password");
            }

        } else {
            // Login failed
            header("Location: login.php?error=User Not Exist");
            exit;
        }
    }

    
}

function findUser($uname, $db) {
    $sql = "SELECT * FROM users WHERE username = '$uname'";
    $result =$db->query($sql);
    
    return $result;
    
}
