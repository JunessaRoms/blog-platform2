<?php
    $categories =get5Categories();
?>
<div class="navbar">
    <div class="logo_content">
        <div class="logo">
            <i class ="fa-solid fa-dice-five"></i>
            <div class="logo_name">&nbsp;BUD</div>
        </div>
        <div class="category_btn">
            <div class="cat-dropdown">
                <button class="dropbtn" id="cat-btn"><h2 class="account_name">CATEGORY</h2></button> 
                <div class="cat-dropdown_cont">

                    <?php foreach($categories AS $category){?>
                    <a href="category.php?catID=<?=$category['category_id']?>"><?=$category['category']?></a>
                    <?php }?>

                </div>
            </div>  
        </div>
        <?php if($logged){ ?>

            <div class="profile_cont">
            <div class="dropdown">
            <button class="dropbtn" id="profbtn"><h2 class="account_name"><?=$_SESSION['username']?></h2></button> 
            <div class="dropdown_cont">
                <a href="logout.php">< Log Out</a>
            </div>
            </div>     
            <img class="profile" src="assets/picsart.jpg" alt=""><br>
            <i class ="fa-solid fa-list" id="btn"></i>
        </div>

        <?php }else{ ?>
        <div class="profile_cont">
            <a href="login.php"><h2 class="account_name"
            style="padding-top:8px;">Login</h2></a>      
            <img class="profile" src="assets/picsart.jpg" alt=""><br>
            <i class ="fa-solid fa-list" id="btn"></i>
        </div>
        <?php }?>
   </div>
</div>