<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/loginstyle.css">
    <title>Login</title>
</head>
<body>
    <div class="container">
        <div class="loginform">
            <h2>JsBlog</h2>
            <form action="login_function.php" method="post">
                <?php if (isset($_GET['error'])) { ?>
                    <p class="error"><?php echo $_GET['error']; ?></p>
                <?php } ?>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username"><br><br>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password"><br><br>
                    
                <div class="remember-label">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">Remember Me</label><br><br>
                </div>

                <div class="button-container">
                <a id="register" href="register.php">SIGNUP</a>
                <input type="submit" value="LOGIN"></input>
                </div>
            </form>
        </div>
    </div>
</body>
</html>