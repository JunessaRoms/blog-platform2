<div class="main_content">
    <div class="post-container">
        <h4>Create a New Post</h4>

        <?php if (isset($_GET['error'])) { ?>
                        <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } elseif (isset($_GET['success'])) {?>
                        <p class="success"><?php echo $_GET['success']; ?></p>
        <?php } ?>

        <?php $authorID= $_GET['authorID']?>
        <!-- Create Post Form -->
        <form method="POST" action="assets/templates/createfunction.php?authorID=<?=$authorID?>" 
        enctype="multipart/form-data">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required>
            <br>
            <label for="content">Content:</label>
            <textarea id="content" name="content" required></textarea>
            <br>
            <div class="category_box">
            <label>Category</label>
            <i class="fa-solid fa-arrow-down" id="cat_drop"></i>
            </div> 
            <div class="cat_drop_cont">
            <div class="cat_box">
                    <?php $categories =getAllCategories();
                    foreach($categories as $category){ ?>
                    <div class="cat_btns">
                        <div style="width: 25px; ">
                            <input type="radio" name="category" id="category-btn" value ="<?=$category['category_id']?>">
                        </div>
                        <label for="category-btn"><?=$category['category']?></label> 
                    </div>          
                    <?php }?>
                    </div>
            </div>
            <br><br>
            <label for="image">Upload Image:</label>
            <input type="file" name="image" id="image" accept="image/*">
            <br>
            <button type="submit" name="submit">Create</button>
        </form>
    </div>
</div>
