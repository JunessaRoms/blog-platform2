<?php
    include "../includes/db.php";
    include "../includes/blog.php";

    $postid = $_GET['postid'];

    if(isset($_POST['commentedit'])&&isset($_GET['comm_id'])) { 
        $comm=$_POST['commentedit'];
        $commID =$_GET['comm_id'];
        $sql= $db->prepare("UPDATE post_comment SET comment=?
        WHERE commentid=?");
        $sql->execute([$comm,$commID]);
    }

            header("Location: ../../read_more.php?postid=$postid");
            exit;

?>