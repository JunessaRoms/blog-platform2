<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unauthorized Access</title>
</head>
<body>
    <h1>Unauthorized Access</h1>
    <p>You do not have the necessary permissions to access this page.</p>
    <p>Please contact the administrator if you believe this is an error.</p>
</body>
</html>