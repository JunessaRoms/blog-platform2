<div class="main_content">
    <div class="cont_container">
    <?php 
        if(isset($_GET['search'])){
            $key = $_GET['search'];
            $blogs = search($key);
            if ($blogs == 0) {
                $notFound = 1;
            }
        }else {
            $user=getuserByUsername($_SESSION['username']);
            $au=getAuthor($user['userid']);
            if($au==0){
                ?>
                <div class="add_post">
                    <a href="register-author.php?userid=<?=$user['userid']?>">+ ADD NEW</a>
                </div>
                <?php
                $blogs=0;

            }else{
            $author = getAuthor($user['userid']);
            $blogs = getPostByAuthorId($author['authorid']);
            ?>
                <div class="add_post">
                    <a href="mypost.php?authorID=<?=$author['authorid']?>">+ ADD NEW</a>
                </div>
            <?php
            }
        }
    ?>


<?php if($blogs !=0){
    foreach($blogs as $post){ ?>
    <div class="post_card">
        <img src="<?=$post['image']?>" alt="" style="width: 350px;">
            <div class="subcon">
            <h3><?=$post['title']?></h3>

             <p>(<?=$post['create_at']?>)</p><br>

            <?php
            $cont =strip_tags($post['content']);
            $cont = substr($cont,0, 250);
            ?>
            <p><?=$cont?>...</p>
            <a href="read_more.php?postid=<?=$post['postid']?>">Read more</a>
            <div class="action-btns">
                    <a href="post-edit.php?postid=<?=$post['postid']?>"
                    style="color:black"><button class="act-btns"><i class ="fa-solid fa-pencil">EDIT</i></a>
                    </button>
                
                    <button class="act-btns" onclick ="ShowModal('myModal-<?=$post['postid']?>')">
                    <i class ="fa-solid fa-trash">Delete</i></button>
                    <?php include "assets/templates/modals/modal-delete.php";?>
        </div>              
            </div>
    </div>
<?php } }?>
    </div>
</div>

