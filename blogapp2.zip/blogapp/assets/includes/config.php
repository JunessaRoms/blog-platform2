<?php
    define('DB_HOST' , 'localhost');
    define('DB_NAME' , 'blogapp');
    define('DB_USER' , 'junessa');
    define('DB_PASS' , 'abominablespice');
?>