let btn = document.querySelector("#btn");
let sidebar = document.querySelector(".sidebar");
let searchBtn = document.querySelector("#search");
let links = document.querySelector(".nav_link");

btn.onclick = function(){
  sidebar.classList.toggle("active");
}
searchBtn.onclick = function(){
  sidebar.classList.toggle("active");
}


const navlinks = document.querySelectorAll(".side_links");
const windowPathname = window.location.pathname;

navlinks.forEach(navlinks=> {
  if(navlinks.href.includes(windowPathname)){
    navlinks.classList.add("activelinks"); 
  }
});
