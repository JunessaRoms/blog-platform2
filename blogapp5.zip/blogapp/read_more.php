<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidestyle.css">
    <link rel="stylesheet"  href="assets/contentstyle.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">
</head>

<body>
    
  <?php

      include "logincheck.php";
      include "assets/includes/blog.php"; 
      include "navbar.php";
      include "sidebar.php";
      include "assets/templates/post_view.php";
  
  ?>

</body>
<script src="assets/js/sidebar.js"></script>
<script src="assets/js/dropdown.js"></script>


</html>