<?php
    include "../includes/db.php";
    include "../includes/blog.php";

    $postid = $_GET['post_id'];
        

    $sql = "DELETE FROM posts WHERE postid=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$postid]);

    header("Location: ../../my_blogs.php");
    exit;

?>