<?php  

session_start();

if(isset($_SESSION['username'])){
    
    include "../includes/db.php";
	include "../includes/blog.php";
    $postid = $_POST['postid'];
	$userid = $_GET['userid'];
	
	if (empty($postid)) {
		echo "...";
	}else {
		$sql = "SELECT * FROM post_likes
		        WHERE postid=? AND userid=?";
    	$stmt = $db->prepare($sql);
    	$res = $stmt->execute([$postid, $userid]);

    	if($stmt->rowCount() > 0){
           // unlike
    		$sql  = "DELETE FROM post_likes
		            WHERE postid=? AND userid=?";
		    $stmt = $db->prepare($sql);
		    $res  = $stmt->execute([$postid, $userid]);

			echo countLikePostId($db, $postid);
    	}else {
            $sql  = "INSERT INTO post_likes(postid,userid) VALUES(?,?)";
		    $stmt = $db->prepare($sql);
		    $res  = $stmt->execute([$postid,$userid]); 

			echo countLikePostId($db, $postid);
    	}
        
    	
	}
	

	
    

}else {
	echo "...";
}