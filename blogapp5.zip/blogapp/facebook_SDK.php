<?php
require_once 'vendor/autoload.php'; // Path to autoload.php from the SDK

$fb = new Facebook\Facebook([
    'app_id' => '279065325177269',
    'app_secret' => '8e0b72e5e35b864f0108c043e3068bd3',
    'default_graph_version' => 'v12.0', 
]);

$helper = $fb->getRedirectLoginHelper();
$permissions = ['username']; // Add additional permissions if needed

$loginUrl = $helper->getLoginUrl('http://localhost/blogapp/index.php', $permissions);

echo '<a href="' . htmlspecialchars($loginUrl) . '">Log in with Facebook!</a>';



try {
    $accessToken = $helper->getAccessToken();
} catch (\Facebook\Exceptions\FacebookResponseException $e) {
    // When Graph returns an error
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch (\Facebook\Exceptions\FacebookSDKException $e) {
    // When validation fails or other local issues
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}

if (!isset($accessToken)) {
    echo 'Access denied: Unauthorized access or user denied permission.';
    exit;
}

?>