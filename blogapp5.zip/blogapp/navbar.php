<?php
    $categories =get5Categories();
?>
<div class="navbar">
    <div class="logo_content">
        <div class="logo">
            <i class ="fa-solid fa-dice-five"></i>
            <div class="logo_name">&nbsp;BUD</div>
        </div>
        <div class="category_btn">
            <div class="cat-dropdown">
                <button class="dropbtn" id="cat-btn"><h2 class="account_name">CATEGORY</h2></button> 
                <div class="cat-dropdown_cont">
                    <?php if($logged){ ?>
                        <?php foreach($categories AS $category){?>
                        <a href="category.php?catID=<?=$category['category_id']?>&token=<?=$_GET['token']?>">
                        <?=$category['category']?></a>
                        <?php }?>
                    <?php }else{ ?>
                        <?php foreach($categories AS $category){?>
                        <a href="category.php?catID=<?=$category['category_id']?>">
                        <?=$category['category']?></a>
                        <?php }?>
                    <?php }?>

                    

                </div>
            </div>  
        </div>
        <?php if($logged){ 
            $user=getuserByUsername($_SESSION['username']);
            $userdetails= getuserDetails($user['userid']);
            ?>
            

            <div class="profile_cont">
            <div class="dropdown">
            <button class="dropbtn" id="profbtn"><h2 class="account_name"><?=$user['username']?></h2></button> 
            <div class="dropdown_cont">
                <a href="logout.php">< Log Out</a>
            </div>
            </div> 
            <?php if(empty($userdetails['prof_pic'])){?>    
            <img class="profile" src="assets/img/usericon.png" alt=""><br>
            <i class ="fa-solid fa-list" id="btn"></i>
            <?php }else{?>
            <img class="profile" src="<?=$userdetails['prof_pic']?>" alt=""><br>
            <i class ="fa-solid fa-list" id="btn"></i>
            <?php }?>
        </div>

        <?php }else{ ?>
        <div class="profile_cont">
            <a href="login.php"><h2 class="account_name"
            style="padding-top:8px;">Login</h2></a>      
            <img class="profile" src="assets/img/usericon.png" alt=""><br>
            <i class ="fa-solid fa-list" id="btn"></i>
        </div>
        <?php }?>
   </div>
</div>