
<html>
<head>
    <title>Home</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:url" content="http://localhost/blogapp/index.php">
    <meta property="og:type" content="website">
    <meta property="og:title" content="MY BLOG">
    <meta property="og:description" content="This is a sample blog app">
    <meta property="og:image" content="">

    <link rel="stylesheet"  href="assets/sidestyle.css">
    <link rel="stylesheet"  href="assets/contentstyle.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">
</head>

<body>
    
  <?php
      include "logincheck.php";
      include "assets/includes/blog.php"; 
      include "navbar.php";
      include "sidebar.php";
      include "content.php";
  
  ?>

</body>
<script src="assets/js/sidebar.js"></script>
<script src="assets/js/like-ajax.js"></script>
<script src="assets/js/dropdown.js"></script>

</html>