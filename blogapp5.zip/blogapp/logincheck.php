<?php
session_start();
include "assets/includes/db.php";
$logged = false;


if(isset($_GET['token'])) {
    $sql = "SELECT * FROM users WHERE user_token=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$_GET['token']]);
    

    if($stmt->rowCount()==1){    
    $user = $stmt->fetch();
    
    $_SESSION['username']=$user['username'];
    $logged = true;
    }else{
        $logged=false;
       
    }
}
?>