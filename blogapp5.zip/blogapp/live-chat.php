<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidestyle.css">
    <link rel="stylesheet"  href="assets/contentstyle.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">

    
</head>

<body>
    
  <?php
      include "logincheck.php";  
      include "assets/includes/blog.php"; 
      include "navbar.php";
      include "sidebar.php";
  ?>


<div class="main_content">
    <div class="cont_container">
    <?php 

        if(isset($_GET['search'])){
            $key = $_GET['search'];
            $posts = search($db, $key);
            if ($posts == 0) {
                $notFound = 1;
            }
        }
        
    ?>

        
        <div class="details-cont">
      
            <div class="details-card" style="width: 800px;">
               
                    <div class="details-text">
                    <h2 style="text-align: center;" id="chatroom"
                    data-value="<?=$_SESSION['username']?>">LIVE CHATROOM</h2><br>
                    <div class="chat_box" style="height:600px;">
                        <div id="chat"></div>

                    </div>

                            <div class="message-bar">
                                <input type="text" id="message" placeholder="Type your message...">
                                <button onclick="sendMessage()" id="mbtn"
                                data-value="<?=$user['userid']?>">Send</button>
                            </div>

                    </div>
            </div>
      
     
        </div>		         
            
    </div>
</div>


</body>
<script src="assets/js/sidebar.js"></script>
<script src="assets/js/dropdown.js"></script>
<script>
      var conn = new WebSocket('ws://localhost:8080');
      var xhr = new XMLHttpRequest();
      var user = document.getElementById('chatroom').getAttribute('data-value');

      const chatList = document.getElementById('chat');


        conn.onopen = function(e) {
            console.log("Connection established!");
        };

        function fetchMessage(){
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var messages = JSON.parse(xhr.responseText);

                        chatList.innerHTML = '';

                            messages.forEach(function(message){

                            var div = document.createElement('div');
                            div.classList.add("allchat");
                            var div2 = document.createElement('div');
                            div2.classList.add("mychat");
                            var img = document.createElement('img');
                            var icon = document.createElement('img');
                            var h3 = document.createElement('h3');
                            var h5 = document.createElement('h5');
                            var li = document.createElement('li');
                            var del =document.createElement('button');
                            del.classList.add("chatdel-btn");
    
                            img.src = message.prof_pic;
                            icon.src="assets/img/usericon.png"
                            h3.textContent = message.username;
                            h5.textContent = message.chatdate;
                            li.textContent = message.message;
                            del.textContent = "Delete";
                            if(message.username==user){

                                var mID= message.messageid;
                                chatList.append(div2);
                                if(message.prof_pic==''){
                                    div2.appendChild(icon);
                                }else{
                                    div2.appendChild(img);
                                }
                                div2.appendChild(h3);
                                div2.appendChild(li);
                               
                                del.onclick =function(){
                                    var xhr2 = new XMLHttpRequest()
                                    xhr2.open('POST', 'deletechatlive.php', true);
                                    xhr2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                                    xhr2.send("mID="+mID);
                                }
                                div2.appendChild(del);
                                div2.appendChild(h5);

                            }else{
                                
                                chatList.append(div);
                                if(message.prof_pic==''){
                                    div.appendChild(icon);
                                }else{
                                    div.appendChild(img);
                                }
                                div.appendChild(h3);
                                div.appendChild(li);
                                div.appendChild(h5);
                            }
                        });
                    }
                }
            };
            xhr.open('GET', 'getmessage.php', true);
            xhr.send();
        }

        function sendMessage() {

            const messageInput = document.getElementById('message');
            var userid = document.getElementById('mbtn').getAttribute('data-value');
            const message = messageInput.value;
        
                xhr.open('POST', 'sendmessage.php?userid='+userid, true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.send('message=' + message);

                messageInput.value = '';
                fetchMessage();
        }

        fetchMessage();
        setInterval(fetchMessage, 2000);

    

     

    </script>

</html>