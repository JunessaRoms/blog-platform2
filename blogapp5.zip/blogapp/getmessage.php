<?php

include "assets/includes/db.php";

$stmt = $db->prepare('SELECT * FROM messages INNER JOIN users ON users.userid= messages.userid
INNER JOIN user_details ON user_details.userid = users.userid LIMIT 10');
$stmt->execute();
$messages = $stmt->fetchAll();

echo json_encode($messages);
